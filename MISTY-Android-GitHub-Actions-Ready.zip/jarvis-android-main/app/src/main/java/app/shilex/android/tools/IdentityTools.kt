package app.shilex.android.tools

import app.shilex.android.data.Settings
import org.json.JSONObject

/** Lets the user rename the assistant by voice ("ab se tumhara naam Rani hai"). */
object IdentityTools {
    fun all(): List<PhoneTool> = listOf(SetAssistantName)

    private object SetAssistantName : PhoneTool {
        override val name = "set_assistant_name"

        override fun declaration() = Schema.function(
            name,
            "Changes the name the assistant answers to, when the user asks for a new name.",
            Schema.string("name", "The new name, one or two words.", required = true),
        )

        override suspend fun run(args: JSONObject, host: ToolHost): JSONObject {
            val newName = args.text("name").trim().take(24)
            if (newName.isEmpty()) return Results.failed("no_name", "Ask what the new name should be.")
            Settings(host.context).assistantName = newName
            return Results.done(
                "Saved. Your name is now $newName: answer to it from now on and tell the user you " +
                    "like it. The spoken wake phrase is separate and doesn't change."
            )
        }
    }
}
