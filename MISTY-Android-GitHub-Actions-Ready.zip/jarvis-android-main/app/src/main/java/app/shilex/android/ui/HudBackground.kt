package app.shilex.android.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** The cinematic backdrop: deep navy, a soft cyan glow behind the core, a faint grid. Drawn once, no animation. */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF03060C), Color(0xFF071426), Color(0xFF03060C))))
        val glowCentre = Offset(size.width / 2f, size.height * 0.34f)
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF2FD6FF).copy(alpha = 0.16f), Color.Transparent), glowCentre, size.width * 0.9f),
            radius = size.width * 0.9f,
            center = glowCentre,
        )
        val step = 48f * density
        val line = Color(0xFF2FD6FF).copy(alpha = 0.04f)
        var x = 0f
        while (x <= size.width) {
            drawLine(line, Offset(x, 0f), Offset(x, size.height), strokeWidth = density)
            x += step
        }
        var y = 0f
        while (y <= size.height) {
            drawLine(line, Offset(0f, y), Offset(size.width, y), strokeWidth = density)
            y += step
        }
    }
}
